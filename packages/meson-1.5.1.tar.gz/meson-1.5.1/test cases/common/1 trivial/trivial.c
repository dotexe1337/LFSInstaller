#include<stdio.h>

int main(void) {
    printf("Trivial test is working.\n");
    return 0;
}
