// cmMod.hpp (P)
#pragma once

#error "cmMod.hpp in incP must not be included"
